<?php
echo $_GET["url"]
?>