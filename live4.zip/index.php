<?php
require_once "./MVC/Bridge.php ";
$myApp= new App();
?>