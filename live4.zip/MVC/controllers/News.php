<?php 
class News{
    function Sayhi(){
        echo "News- Sayhi";
    }
}
?>