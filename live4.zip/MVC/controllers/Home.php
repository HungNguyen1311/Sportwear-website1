<?php
class Home extends Controller{
    function SayHi(){
        $this->view("aodep");
    }
    function Show(){
        $this->view("aodep");
    }
}
?>