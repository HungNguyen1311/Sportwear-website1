<?php
    include "connectDB.php";
    $resturn_arr = array();
    $sql = "SELECT hinh,tenhh,gia,id FROM giay";
    $result=$con->query($sql);
    $i = 0;
    while($row = mysqli_fetch_array($result)){
        $id = $row['id'];
        $hinh = $row['hinh'];
        $ten = $row['tenhh'];
        $gia =$row['gia'];
        $t= array(
                        "id"=>$id,
                        "hinh" => $hinh,
                        "ten" => $ten,
                        "gia" => $gia);
        array_push($resturn_arr,$t);
         }
//    for($i=0;$i<5;$i++){
//        print_r($resturn_arr[$i]);
//        echo("<br>");
//    }
// Encoding array in JSON format
//$res=json_encode($resturn_arr);
//echo($res);
$size=count($resturn_arr);
?>