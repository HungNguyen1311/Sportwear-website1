<!doctype html>
<head>
<style>
div{padding:20px}
#header,#footer{
    background-color:yellow;
}
</style>
</head>
<body>
    <div id="header"></div>
    <div id="content">
    <?php
    require_once "./MVC/views/pages/".$data["Page"].".php"
    ?>
    </div>

</body>
</html>
