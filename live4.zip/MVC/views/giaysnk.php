<html>
    <head>
    <title></title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="../Public/css/style.css"/>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <script>
            var index=0
            ChangeImg=function (){
                var imgs =["../Public/Wall/Wall.png","../Public/Wall/Wall2.png","../Public/Wall/Wall6.jpg","../Public/Wall/Wall8.jpg","../Public/Wall/Wall5.png"];
                document.getElementById('img').src=imgs[index];
                index++;
                if(index==5){
                    index=0;
                }                
            }
            setInterval(ChangeImg,2000);
        </script>
        </head>
        <body>
    <div class="box2">
                <div class="item">
                    <div class="Menu">
                        <a href="https://vnexpress.net/"><img src="../Public/pic/AoBD/logo3.PNG" width="280" height="70"></a>
                    </div>
                    <div class="Menu">
                        <ul class="Root">
                            <li id="trangchu"><a href="<?php echo"home.php" ?>"><strong>TRANG CHỦ </strong></a></li>
                            <li><a href=""><strong>ÁO THỂ THAO<i class="fa fa-caret-down" aria-hidden="true"></i> </strong></a>
                            <ul class="SubMenu">
                                <li><a href="">Áo Đá Bóng</a></li>
                                <li><a href="">Áo Thủ Gôn</a></li>
                                <li><a href="">Áo Phông</a></li>
        
                            </ul>
                            </li>                           
                            <li><a href=""><strong>GIÀY THỂ THAO <i class="fa fa-caret-down" aria-hidden="true"></i>  </strong></a>
                            <ul class="SubMenu">
                                <li><a href="">Giày Bóng Đá Nike </a></li> 
                                <li><a href="">Giày Thể Thao Sneaker </a></li>
                                <li><a href="">Giày Running </a></li>
                            </ul>
                        </li>
                            <li><a href=""><strong>PHỤ KIỆN KHÁC  </strong></a>                           
                            </li>                          
                            <li><a href=""><strong>LIÊN HỆ  </strong></a></li>
                     </ul>
                    </div>
                    <div class="Menu">
                        <div class="Menu1"><u>Giỏ Hàng</u> | <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                        </div>
                        <div class="Menu1"><a href=""><u>Đăng nhập|<i class="fa fa-user" aria-hidden="true"></i>
                        </u></a></div>
                    </div>
                </div>
                <div class="item">
                    <div class="TK">
                        <div class="TK1">                        
                            <input type="search" name="Tìm Kiếm" placeholder="Tìm Kiếm của bạn...">
                            <a href="#" class="search-btn">
                            <i class="fa fa-search"  style="color:grey"></i>
                            </a>
                        </div>
                    </div>
                    <div class="TK">
                        <div class="Wall"> 
                            <img id="img" onclick="ChangeImg()" src="../Public/Wall/Wall.png" alt="" height="385px" width="90%">; 
                        </div>
                    </div>
                </div>
                <div class="chitiet2">
                    <div class="sanpham1">
                        <div class="tieude"><strong>CÁC SẢN PHẨM </strong></div>
                            <div class="noidung">
                                <div class="kid">
                                    <?php
                                        include "../core/getdataGiay.php";
                                        $cell="";
                                        for($i=3; $i<5; $i++){
                                            $cell="<div class='boy'>".
                                                            "<div class='B1'><IMG SRC='".$resturn_arr[$i]['hinh']."' width:100 height=250 ></div>".
                                                            "<div class='B1'>".$resturn_arr[$i]['ten']."</div>".
                                                            "<div class='B1'><strong>".$resturn_arr[$i]['gia']."</strong></div>".
                                                        "</div>";    
                                                echo($cell);
                                        }                                 
                                    ?>
                            </div>
                    </div>
                </div>                  
    </div>       
                <div class="cuoicung">
                    <div class="cuoiTrang">
                    <Strong>KICK EA SPORTSHOP</Strong><br><br>
                            <Strong>Địa Chỉ:</Strong><br>
                            <strong>Sóc Trăng :</strong>67 đường Tôn Đức Thắng, Khóm 5,Phường 6,Thành Phố Sóc Trăng.<br>
                            <strong>Cần Thơ :</strong>Số 139 đường Trần Vĩnh Kiết,quận Ninh Kiều,Phường An Bình,Thành Phố Cần Thơ<br><br><br>
                            <Strong>Address:</Strong><br>
                            <strong>Sóc Trăng City :</strong>67 Ton Duc Thang Street, Hamlet 5, Ward 6, Soc Trang City.<br>
                            <strong>Cần Thơ City:</strong>139 Tran Vinh Kiet Street, Ninh Kieu District, An Binh Ward, Can Tho City.<br><br><br>
                            <strong>HOTLINE:0834445508</strong><br>
                            <strong>Thời Gian Làm Việc:</strong>Thứ hai - Chủ nhật 8.00 am - 21:30 pm.
                    </div>
                    <div class="cuoitrang">
                    <Strong>KICK EA SPORTSHOP Cam Kết</Strong><br><br>
                           - Đảm bảo chất lượng sản phẩm tốt nhất, vận chuyển trên toàn quốc<br><br>
                           - Giá cả cân bằng với chất lượng<br><br>
                           - Đổi/trả hàng lỗi do nhà sản xuất chậm nhất trong 3 ngày<br><br>
                           - Bảo mật thanh toán khi khách hàng thanh toán online<br><br>
                           - Phục vụ khách hàng 24/7<br><br>
                           - Giới Thiệu<br><br>
                           - Khách Hàng<br><br>
                           - Đối Tác<br><br>
                    </div>
                    <div class="cuoitrang">
                <strong>GIAO HÀNG TOÀN QUỐC</strong><br><br>  
    – Giao hàng và thanh toán sau khi kiểm tra:<br><br>
    – Phí vận chuyển 30K, miễn phí các đơn >299K.<br><br>
    – Thành phố từ 1-2 ngày, huyện xã 3-4 ngày.<br><br>
    – Giao trong ngày phí 10k-20K và miễn phí cho các đơn >299k ở nội thành Cần Thơ. (khẩn cấp phí cao hơn)<br><br>
    – Để biết thêm chi tiết vui lòng liên hệ 083 444 5508<br><br>
    – Chúc các bạn mua sắm vui vẻ tại KICK EA SPORTSHOP!</div><br><br>
                    </div>
                </div>             
            </div>                                  
    </body>
</html>