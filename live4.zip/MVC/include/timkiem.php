<?php
    if(isset($_POST['search_button'])){
        $tukhoa=$_POST['search_product'];
        $sql_product=mysqli_query($con,"SELECT * from hanghoa where tenhh like '%$tukhoa%' order by id DESC");
        $sql_product2=mysqli_query($con,"SELECT * from aophong where tenhh like '%$tukhoa%' order by id DESC");
        $sql_product3=mysqli_query($con,"SELECT * from giay where tenhh like '%$tukhoa%' order by id DESC");
        $title=$tukhoa;
        $count1=mysqli_num_rows($sql_product);
        $count2=mysqli_num_rows($sql_product2);
        $count3=mysqli_num_rows($sql_product3);

    }
?>
<?php if($count1>0){?>
<div class="chitiet">
<h3 id="timkiem">Tìm Kiếm :<?php echo $title ?></h3>
    <div class="sanpham"><div class="noidung">
                <div class="kid">
                <?php while($row_sanpham=mysqli_fetch_array($sql_product)){ ?>                
                                <div class="boy">                                    
                                    <div class="B1"><IMG SRC="<?php echo $row_sanpham['hinh']?>" width:100 height=250 ></div>
                                    <div class="B1"><?php echo $row_sanpham['tenhh']?></div>
                                    <div class="B1"><strong><?php echo $row_sanpham['gia']?></strong></div>
                                </div>
<?php } ?>
                </div>
        </div>
    </div>
                <?php } ?>
    <?php if($count2 >0 ){ ?>
    <div class="sanpham">
        <div class="noidung">
            <div class="kid">
            <?php while($row_sanpham=mysqli_fetch_array($sql_product2)){ ?>                
                                <div class="boy">                                    
                                    <div class="B1"><IMG SRC="<?php echo $row_sanpham['hinh']?>" width:100 height=250 ></div>
                                    <div class="B1"><?php echo $row_sanpham['tenhh']?></div>
                                    <div class="B1"><strong><?php echo $row_sanpham['gia']?></strong></div>
                                </div>
<?php } ?>
                     </div>
             </div>
        </div>
            <?php } ?>
        <?php if($count3 >0 ){ ?>
    <div class="sanpham">
        <div class="noidung">
        <div class="kid">
        <?php while($row_sanpham=mysqli_fetch_array($sql_product3)){ ?>                
                                <div class="boy">                                    
                                    <div class="B1"><IMG SRC="<?php echo $row_sanpham['hinh']?>" width:100 height=250 ></div>
                                    <div class="B1"><?php echo $row_sanpham['tenhh']?></div>
                                    <div class="B1"><strong><?php echo $row_sanpham['gia']?></strong></div>
                                </div>
<?php } ?>
             </div>
        </div>
    </div>
        <?php } ?>
</div>           