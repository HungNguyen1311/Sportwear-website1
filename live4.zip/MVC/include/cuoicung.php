</a>
<div class="cuoicung">
                    <div class="cuoiTrang">
                    <Strong>KICK EA SPORTSHOP</Strong><br><br>
                            <Strong>Địa Chỉ:</Strong><br>
                            <strong>Sóc Trăng :</strong>67 đường Tôn Đức Thắng, Khóm 5,Phường 6,Thành Phố Sóc Trăng.<br>
                            <strong>Cần Thơ :</strong>Số 139 đường Trần Vĩnh Kiết,quận Ninh Kiều,Phường An Bình,Thành Phố Cần Thơ<br><br><br>
                            <Strong>Address:</Strong><br>
                            <strong>Sóc Trăng City :</strong>67 Ton Duc Thang Street, Hamlet 5, Ward 6, Soc Trang City.<br>
                            <strong>Cần Thơ City:</strong>139 Tran Vinh Kiet Street, Ninh Kieu District, An Binh Ward, Can Tho City.<br><br><br>
                            <strong>HOTLINE:0834445508</strong><br>
                            <strong>Thời Gian Làm Việc:</strong>Thứ hai - Chủ nhật 8.00 am - 21:30 pm.
                    </div>
                    <div class="cuoitrang">
                    <Strong>KICK EA SPORTSHOP Cam Kết</Strong><br><br>
                           - Đảm bảo chất lượng sản phẩm tốt nhất, vận chuyển trên toàn quốc<br><br>
                           - Giá cả cân bằng với chất lượng<br><br>
                           - Đổi/trả hàng lỗi do nhà sản xuất chậm nhất trong 3 ngày<br><br>
                           - Bảo mật thanh toán khi khách hàng thanh toán online<br><br>
                           - Phục vụ khách hàng 24/7<br><br>
                           - Giới Thiệu<br><br>
                           - Khách Hàng<br><br>
                           - Đối Tác<br><br>
                    </div>
                    <div class="cuoitrang">
                <strong>GIAO HÀNG TOÀN QUỐC</strong><br><br>  
    – Giao hàng và thanh toán sau khi kiểm tra:<br><br>
    – Phí vận chuyển 30K, miễn phí các đơn >299K.<br><br>
    – Thành phố từ 1-2 ngày, huyện xã 3-4 ngày.<br><br>
    – Giao trong ngày phí 10k-20K và miễn phí cho các đơn >299k ở nội thành Cần Thơ. (khẩn cấp phí cao hơn)<br><br>
    – Để biết thêm chi tiết vui lòng liên hệ 083 444 5508<br><br>
    – Chúc các bạn mua sắm vui vẻ tại KICK EA SPORTSHOP!</div><br><br>
                    </div>
                </div>             
            </div>                                  
    </body>
</html>