<div class="chitiet2">
    <div class="sanpham1">
        <div class="tieude"><strong>CÁC SẢN PHẨM </strong></div>
            <div class="noidung">
                <div class="kid">
                    <?php
                        include "./MVC/core/getdataAothidau.php";
                        $cell="";
                            for($i=0; $i<5; $i++){
                                $cell="<div class='boy'>".
                                "<div class='B1'><IMG SRC='".$resturn_arr[$i]['hinh']."' width:100 height=250 ></div>".
                                "<div class='B1'><a href='?quanly=chitietsp1&id=".$resturn_arr[$i]['id']."'>".$resturn_arr[$i]['ten']."<a></div>".
                                "<div class='B1'><strong>".$resturn_arr[$i]['gia']."</strong></div>".
                                "</div>";    
                                echo($cell);
                                        }                                 
                                    ?>
                            </div>
                    </div>
                </div>                  
    </div>       