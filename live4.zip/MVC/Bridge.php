<?php
require_once "./MVC/core/App.php";
require_once "./MVC/core/Controller.php";
require_once "./MVC/core/DB.php";
require_once "./MVC/core/getdataAophong.php";
require_once "./MVC/core/getdataAothidau.php";
require_once "./MVC/core/getdataGiay.php";
?>